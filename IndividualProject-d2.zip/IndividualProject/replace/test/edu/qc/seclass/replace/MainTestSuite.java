package edu.qc.seclass.replace;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;

@RunWith(Suite.class)
@Suite.SuiteClasses({MainTest.class, MyMainTest.class, MainTestAddOn.class})

public class MainTestSuite {}

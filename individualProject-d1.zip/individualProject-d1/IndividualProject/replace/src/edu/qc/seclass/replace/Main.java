package edu.qc.seclass.replace;

public class Main {

    public static void main(String[] args) {
        // TODO: Empty skeleton method
    }

    private static void usage() {
        System.err.println("Usage: Replace [-b] [-f] [-l] [-i] <from> <to> -- " + "<filename> [<filename>]*" );
    }

}